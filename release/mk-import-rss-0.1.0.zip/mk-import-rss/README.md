# MK Import RSS

Плагин Obsidian для импорта элементов RSS-ленты в markdown-заметки.

## Что делает плагин

- Загружает RSS по URL и превращает элементы ленты в заметки.
- Может обрабатывать XML-файлы из inbox-папки внутри vault.
- Создаёт папки и имена заметок по шаблонам.
- Добавляет метаданные `mk_*` во frontmatter.
- Может вставлять удалённые картинки или скачивать их в vault.

## Как установить сейчас

### Самый простой вариант для macOS

1. Скачайте zip-архив релиза из GitHub Releases.
2. Распакуйте архив.
3. Откройте папку `mk-import-rss`.
4. Дважды кликните `install-mk-import-rss.command`.
5. Когда Finder попросит, выберите папку вашего vault Obsidian.
6. В Obsidian откройте `Settings -> Community plugins`.
7. Если community plugins ещё выключены, включите их.
8. Включите плагин `MK Import RSS` в списке установленных.

Если macOS блокирует запуск, нажмите правой кнопкой по файлу и выберите `Open`.

### Самый простой вариант для Windows

1. Скачайте zip-архив релиза из GitHub Releases.
2. Распакуйте архив.
3. Откройте папку `mk-import-rss`.
4. Кликните правой кнопкой по `install-mk-import-rss.ps1`.
5. Выберите `Run with PowerShell`.
6. Выберите папку вашего vault Obsidian в открывшемся диалоге.
7. В Obsidian откройте `Settings -> Community plugins`.
8. Если community plugins ещё выключены, включите их.
9. Включите плагин `MK Import RSS` в списке установленных.

Если PowerShell блокирует запуск, откройте PowerShell от имени текущего пользователя и выполните:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-mk-import-rss.ps1
```

### Ручная установка

1. Соберите проект или возьмите из релиза эти файлы:
   - `manifest.json`
   - `main.js`
2. Откройте папку вашего vault.
3. Создайте папку:

```text
.obsidian/plugins/mk-import-rss/
```

4. Скопируйте `manifest.json` и `main.js` в эту папку.
5. Перезапустите Obsidian или перезагрузите community plugins.
6. Включите `MK Import RSS` в `Settings -> Community plugins`.

## Как собрать из исходников

```bash
npm install
npm run build
```

На выходе будут:

- `main.js`
- `manifest.json`

## Как подготовить zip-релиз

```bash
npm run package
```

Будут созданы:

- `release/mk-import-rss/`
- `release/mk-import-rss-0.1.0.zip`

Внутри релизной папки лежат файлы плагина, установщик, лицензия и инструкция.

## Как сделать установку одной кнопкой

### Лучший официальный вариант

После публикации плагина в официальном каталоге community plugins Obsidian можно давать пользователям такую ссылку:

```text
obsidian://show-plugin?id=mk-import-rss
```

Эта ссылка открывает страницу плагина прямо в Obsidian. Для обычного пользователя это самый понятный сценарий "в одну кнопку".

### Пока плагин ещё не опубликован

Самый простой сценарий сейчас: давать пользователю zip-релиз с файлами `install-mk-import-rss.command` для macOS и `install-mk-import-rss.ps1` для Windows.

Если репозиторий будет опубликован на GitHub и нужен удобный способ раздавать бета-версии по URL, обычно используют BRAT. Это не официальный способ установки Obsidian, но он удобен для тестирования неопубликованных плагинов.

## Важно для обновления старой версии

Раньше у плагина был id `prefix-organizer`. Сейчас используется `mk-import-rss`.

Если где-то уже стояла старая локальная версия, сначала удалите старую папку:

```text
.obsidian/plugins/prefix-organizer/
```

Потом установите новую версию в:

```text
.obsidian/plugins/mk-import-rss/
```
